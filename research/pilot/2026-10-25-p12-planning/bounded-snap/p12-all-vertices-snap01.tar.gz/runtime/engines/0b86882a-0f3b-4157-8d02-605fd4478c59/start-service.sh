#!/bin/sh
valhalla_service /work/service-config.json 1 > /work/daemon.stdout.log 2> /work/daemon.stderr.log &
p=$!
echo "$p" > /work/daemon.pid
wait "$p"
s=$?
echo "$s" > /work/daemon.exit
exit "$s"
