# Signed synthetic publication / 서명 합성 게시

Actual GPS → HTTP → P05 matching → P06 candidate → signed immutable HTTP bytes → durable consumer.
실제 GPS→HTTP→P05매칭→P06후보→서명 불변HTTP바이트→영속수신.

P08 engine activation, production HTTPS/authentication and real-road accuracy remain unimplemented. Offline bytes are not instantly recalled by revocation.
P08엔진활성화·운영HTTPS/인증·실도로정확도는 미구현이며 철회가 오프라인 바이트를 즉시 회수하지 않습니다.
