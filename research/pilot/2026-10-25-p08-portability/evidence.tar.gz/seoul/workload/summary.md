# Seoul OSM engineering round trip / 서울 OSM 처리 흐름 검사

© OpenStreetMap contributors — https://www.openstreetmap.org/copyright (ODbL).
License / 라이선스: https://opendatacommons.org/licenses/odbl/1-0/
Source / 원본: https://download.geofabrik.de/asia/south-korea-261023.osm.pbf
Synthetic vehicles, not real driver traces or reviewed road accuracy.
합성 차량이며 실주행 기록·검토한 실도로 정확도가 아닙니다.
