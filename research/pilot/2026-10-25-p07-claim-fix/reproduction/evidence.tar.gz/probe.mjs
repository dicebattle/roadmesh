import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import pg from 'pg';
import assert from 'node:assert/strict';
import { OwnedIngestionRuntime } from '../../dist/tools/ingestion_runtime.js';
import { IngestionStore } from '../../dist/tools/ingestion_store.js';
const root=resolve('data/p05-claim-race-probe');
const owner=new OwnedIngestionRuntime(root+'/runtime',root);
const source=readFileSync('tools/ingestion_store.ts','utf8');
const query=source.match(/"(SELECT c\.\* FROM routelens_p05\.contributors c WHERE c.namespace=\$1[^"\n]+)"/)[1];
const tripQuery=source.match(/"(SELECT \* FROM routelens_p05\.trips WHERE namespace=\$1 AND contributor_id=\$2 AND graph_id=\$3[^"\n]+)"/)[1];
const gated=query.replace('SELECT c.* FROM','SELECT c.*, probe_gate(c.contributor_id) AS probe_gate FROM');
writeFileSync(root+'/queries.sql',query+';\n\n'+gated+';\n\n'+tripQuery+';\n');
const events=[];const record=(kind,value)=>{events.push({kind,value});writeFileSync(root+'/results.json',JSON.stringify(events,null,2)+'\n');};
let pool,store;const clients=[];
try {
 const url=await owner.start();pool=new pg.Pool({connectionString:url,max:6});
 const config={namespace:'claim-race-probe',graph_id:'a'.repeat(64),matching_policy:'seoul-observed-v3',database_url:url};
 store=new IngestionStore(config);await store.initialize();
 const n=config.namespace,g=config.graph_id,p=config.matching_policy,time='2026-10-25T00:00:00.000Z';
 // Only initial test-fixture population is direct SQL. All subsequent claim state changes use the production store.
 await pool.query("INSERT INTO routelens_p05.contributors VALUES($1,'a','vehicle-a','pilot-consent-v1',true),($1,'b','vehicle-b','pilot-consent-v1',true)",[n]);
 await pool.query(`INSERT INTO routelens_p05.trips(namespace,contributor_id,trip_id,vehicle_id,graph_id,matching_policy,consent_version,source_class,trip_start_utc,state,first_received_at,last_activity_at,raw_expires_at,tombstone_expires_at) SELECT $1,c,'trip-'||c,'vehicle-'||c,$2,$3,'pilot-consent-v1','SYNTHETIC',$4::timestamptz,'READY',$4::timestamptz,$4::timestamptz,$4::timestamptz+interval '10 minutes',$4::timestamptz+interval '24 hours' FROM unnest(ARRAY['a','b']) c`,[n,g,p,time]);
 await store.advanceEventTime(time);
 await pool.query(`CREATE FUNCTION probe_gate(text) RETURNS text LANGUAGE plpgsql VOLATILE AS $$ BEGIN PERFORM pg_advisory_xact_lock(508025); RETURN $1; END $$`);
 const a=await pool.connect(),control=await pool.connect();clients.push(a,control);
 record('server',(await a.query("SELECT version(),current_setting('transaction_isolation') isolation")).rows);
 record('initial',(await pool.query('SELECT contributor_id,state,fence,attempt FROM routelens_p05.trips ORDER BY contributor_id')).rows);
 record('explain',(await a.query('EXPLAIN (VERBOSE,FORMAT JSON) '+gated,[n,g,p])).rows);
 const pid=(await a.query('SELECT pg_backend_pid() pid')).rows[0].pid;
 await control.query('SELECT pg_advisory_lock(508025)');
 await a.query('BEGIN');
 await a.query('SELECT event_time_utc FROM routelens_p05.namespace_clock WHERE namespace=$1 FOR SHARE',[n]);
 let gatedError;const pending=a.query(gated,[n,g,p]).catch(e=>{gatedError=e;return null});
 // Condition polling observes the deterministic barrier, not a timing-based workload retry.
 const deadline=Date.now()+10000;let lock;
 while(Date.now()<deadline){lock=(await control.query("SELECT pid,locktype,mode,granted FROM pg_locks WHERE pid=$1 AND locktype='advisory' AND NOT granted",[pid])).rows;if(lock.length)break;await new Promise(r=>setImmediate(r));}
 assert.equal(lock.length,1,'A must reach advisory projection barrier');record('a-blocked',lock);
 // If A already held contributor a, this NOWAIT probe would fail. Rollback leaves no state mutation.
 const verifier=await pool.connect();clients.push(verifier);await verifier.query('BEGIN');
 record('a-not-yet-rowlocked',(await verifier.query("SELECT contributor_id FROM routelens_p05.contributors WHERE namespace=$1 AND contributor_id='a' FOR UPDATE NOWAIT",[n])).rows);await verifier.query('ROLLBACK');
 const b=await store.claim('worker-b',time,120000);record('production-b-claim',b);assert.equal(b.contributor_id,'a');
 record('after-b-commit',(await pool.query('SELECT contributor_id,state,fence,attempt FROM routelens_p05.trips ORDER BY contributor_id')).rows);
 await control.query('SELECT pg_advisory_unlock(508025)');
 const first=await pending;if(gatedError)throw gatedError;record('a-stale-contributor',first.rows);assert.equal(first.rows[0].contributor_id,'a');
 const second=await a.query(tripQuery,[n,'a',g,p]);record('a-next-statement-trip',second.rows);assert.equal(second.rows.length,0);await a.query('COMMIT');
 const remaining=(await pool.query("SELECT contributor_id,state FROM routelens_p05.trips WHERE state='READY' ORDER BY contributor_id")).rows;record('remaining-ready',remaining);assert.deepEqual(remaining,[{contributor_id:'b',state:'READY'}]);
 record('production-next-claim',await store.claim('worker-c',time,120000));
 record('outcome','CONFIRMED: A selected stale contributor a, next statement found no eligible trip while b remained READY.');
} catch(e){record('error',{message:e.message,stack:e.stack});process.exitCode=1;}
finally {for(const c of clients){await c.query('ROLLBACK').catch(()=>{});await c.query('SELECT pg_advisory_unlock_all()').catch(()=>{});c.release();}if(store)await store.close();if(pool)await pool.end();record('cleanup',await owner.cleanup());}
