/** Bounded persistent-engine capability probe, not P09 implementation.
 * 지속 엔진 실행 능력의 제한 조사이며 P09 구현이 아닙니다. */
import { randomUUID, createHash } from "node:crypto";
import { readFileSync, writeFileSync, copyFileSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { spawnSync } from "node:child_process";
import assert from "node:assert/strict";
const output = resolve("data/p09-engine-service-probe"),
  graph = resolve("data/p08-main-20261025/seoul/graph"),
  blank = resolve("data/p08-main-20261025/traffic/bundle/traffic.tar");
const manifest = JSON.parse(readFileSync(join(graph, "manifest.json"))),
  bundle = JSON.parse(
    readFileSync(
      resolve("data/p08-main-20261025/traffic/bundle/manifest.json"),
    ),
  );
const hash = (b) => createHash("sha256").update(b).digest("hex"),
  run = randomUUID(),
  name = "routelens-p09-service-" + run;
const originalRequest = JSON.parse(
    readFileSync(join(graph, "route-teheran.request.json")),
  ),
  request = { ...originalRequest, date_time: { type: 0 } };
assert.equal(manifest.graph_id, bundle.graph_id);
assert.equal(manifest.image.id, bundle.image_id);
assert.equal(hash(readFileSync(blank)), bundle.skeleton_sha256);
const copied = join(output, "traffic.tar");
copyFileSync(blank, copied);
assert.equal(hash(readFileSync(copied)), bundle.skeleton_sha256);
const config = JSON.parse(readFileSync(join(graph, "config.json")));
Object.assign(config.mjolnir, {
  tile_dir: "/graph/tiles",
  tile_extract: "",
  traffic_extract: "/work/traffic.tar",
  admin: "/graph/no-admin.sqlite",
  timezone: "/graph/no-timezone.sqlite",
});
config.httpd.service.listen = "tcp://127.0.0.1:8002";
writeFileSync(
  join(output, "service-config.json"),
  JSON.stringify(config, null, 2) + "\n",
);
writeFileSync(
  join(output, "request.json"),
  JSON.stringify(request, null, 2) + "\n",
);
writeFileSync(
  join(output, "expected.json"),
  JSON.stringify(
    {
      scope_en:
        "One predeclared persistent HTTP engine capability experiment; not activation/draining or P09 completion.",
      scope_ko:
        "사전에 정한 지속 HTTP 엔진 실행 능력 실험 한 번이며 활성화·요청 마무리나 P09 완료가 아닙니다.",
      graph_id: manifest.graph_id,
      graph_manifest_sha256: hash(readFileSync(join(graph, "manifest.json"))),
      image_id: manifest.image.id,
      baseline_skeleton_sha256: bundle.skeleton_sha256,
      sequence: [
        "installed help/tools survey",
        "single valhalla_service config concurrency1 start",
        "observe loopback listener without HTTP readiness requests",
        "two identical POST /route requests via installed curl",
        "same engine PID and start ticks before/after requests",
        "TERM exact engine PID then remove exact owned container and verify absence",
      ],
      request,
      requirements: {
        http_route_count: 2,
        status_codes: [200, 200],
        both_valid_json: true,
        same_daemon_pid_and_start_ticks: true,
        no_daemon_restart: true,
        network: "none",
        host_ports: [],
        cpus: 2,
        memory_bytes: 4294967296,
        graph_readonly: true,
      },
    },
    null,
    2,
  ) + "\n",
);
writeFileSync(
  join(output, "ownership.json"),
  JSON.stringify(
    {
      run_id: run,
      container: name,
      label: "io.routelens.p09-probe=" + run,
      work_directory: output,
      graph_directory: graph,
      planned_before_creation: true,
    },
    null,
    2,
  ) + "\n",
);
const records = [],
  observations = {};
let created = false,
  cleanup = false,
  daemonCleanup = false,
  failure;
function docker(args, { allow = false, timeout = 30000 } = {}) {
  const r = spawnSync("docker", args, {
      encoding: "utf8",
      timeout,
      maxBuffer: 16 * 1024 * 1024,
    }),
    id = String(records.length + 1).padStart(3, "0");
  writeFileSync(join(output, id + ".stdout.log"), r.stdout ?? "");
  writeFileSync(join(output, id + ".stderr.log"), r.stderr ?? "");
  records.push({
    id,
    args,
    status: r.status,
    error: r.error ? String(r.error) : null,
    stdout: id + ".stdout.log",
    stderr: id + ".stderr.log",
  });
  writeFileSync(
    join(output, "commands.json"),
    JSON.stringify(records, null, 2) + "\n",
  );
  if (!allow && (r.error || r.status !== 0))
    throw Error("Command failed / 명령 실패: " + id);
  return r;
}
const exec = (args, opts) => docker(["exec", name, ...args], opts);
function identity(label) {
  const r = exec([
    "/bin/sh",
    "-c",
    'p=$(cat /work/daemon.pid); kill -0 "$p" && printf "%s " "$p" && cat "/proc/$p/stat"',
  ]);
  const match = /^(\d+) (\d+) \(([^)]+)\) (.*)$/.exec(r.stdout.trim());
  assert.ok(match, "Native /proc identity / 실제 프로세스 식별");
  const fields = match[4].split(" ");
  const value = {
    pid: Number(match[1]),
    proc_pid: Number(match[2]),
    comm: match[3],
    state: fields[0],
    start_ticks: fields[19],
    raw: r.stdout.trim(),
  };
  assert.equal(value.pid, value.proc_pid);
  assert.notEqual(value.state, "Z");
  observations[label] = value;
  return value;
}
try {
  docker([
    "create",
    "--name",
    name,
    "--label",
    "io.routelens.p09-probe=" + run,
    "--network",
    "none",
    "--cpus",
    "2",
    "--memory",
    "4g",
    "--stop-timeout",
    "1",
    "--mount",
    "type=bind,src=" + output + ",dst=/work",
    "--mount",
    "type=bind,src=" + graph + ",dst=/graph,readonly",
    "--entrypoint",
    "/bin/sh",
    manifest.image.id,
    "-c",
    "exec sleep 900",
  ]);
  created = true;
  docker(["start", name]);
  const inspect = JSON.parse(docker(["inspect", name]).stdout)[0];
  writeFileSync(
    join(output, "container-inspect.json"),
    JSON.stringify(inspect, null, 2) + "\n",
  );
  assert.equal(inspect.HostConfig.NetworkMode, "none");
  assert.equal(inspect.HostConfig.Memory, 4294967296);
  assert.equal(inspect.HostConfig.NanoCpus, 2000000000);
  assert.ok(
    !inspect.HostConfig.PortBindings ||
      Object.keys(inspect.HostConfig.PortBindings).length === 0,
  );
  assert.ok(
    inspect.Mounts.some(
      (m) => m.Destination === "/graph" && !m.RW && m.Source === graph,
    ),
  );
  exec(
    [
      "/bin/sh",
      "-c",
      'uname -a; for t in curl wget ps ss timeout; do command -v "$t" || true; done; valhalla_service --version; valhalla_service --help',
    ],
    { allow: true },
  );
  const curl = exec(["/bin/sh", "-c", "command -v curl"], { allow: true });
  if (curl.status !== 0)
    throw Error(
      "Installed curl missing; no HTTP attempt / 설치된 curl 없음·HTTP 시도 안 함",
    );
  // Exactly one service start. Shell waits and reaps that same child; no restart fallback.
  // 서비스는 한 번만 시작하고 셸이 같은 자식의 종료를 회수하며 다른 시작 방식은 시도하지 않습니다.
  writeFileSync(
    join(output, "start-service.sh"),
    '#!/bin/sh\nvalhalla_service /work/service-config.json 1 > /work/daemon.stdout.log 2> /work/daemon.stderr.log &\np=$!\necho "$p" > /work/daemon.pid\nwait "$p"\ns=$?\necho "$s" > /work/daemon.exit\nexit "$s"\n',
  );
  docker(["exec", "-d", name, "/bin/sh", "/work/start-service.sh"]);
  const deadline = Date.now() + 30000;
  let ready = false;
  while (Date.now() < deadline) {
    const r = exec(
      [
        "/bin/sh",
        "-c",
        'test -s /work/daemon.pid || exit 2; p=$(cat /work/daemon.pid); kill -0 "$p" || exit 3; awk \'$2=="0100007F:1F42" && $4=="0A" {found=1} END{exit !found}\' /proc/net/tcp',
      ],
      { allow: true },
    );
    if (r.status === 0) {
      ready = true;
      break;
    }
    if (
      r.status === 3 ||
      (existsSync(join(output, "daemon.exit")) &&
        readFileSync(join(output, "daemon.exit")).length)
    )
      break;
    await new Promise((r) => setTimeout(r, 200));
  }
  assert.ok(
    ready,
    "No loopback HTTP listener from the single service start / 단일 시작에서 HTTP loopback 리스너 없음",
  );
  const before = identity("before_requests");
  for (let i = 1; i <= 2; i++) {
    const r = exec([
      "curl",
      "--silent",
      "--show-error",
      "--max-time",
      "20",
      "--request",
      "POST",
      "--header",
      "Content-Type: application/json",
      "--data-binary",
      "@/work/request.json",
      "--dump-header",
      "/work/route-" + i + ".headers.txt",
      "--output",
      "/work/route-" + i + ".response.json",
      "--write-out",
      "%{http_code}",
      "http://127.0.0.1:8002/route",
    ]);
    assert.equal(r.stdout.trim(), "200");
    const result = JSON.parse(
      readFileSync(join(output, "route-" + i + ".response.json")),
    );
    assert.equal(result.trip?.status, 0);
    assert.equal(result.trip?.legs?.length, 1);
    const current = identity("after_request_" + i);
    assert.equal(current.pid, before.pid);
    assert.equal(current.start_ticks, before.start_ticks);
    observations["route_" + i] = {
      http_status: 200,
      trip_status: result.trip.status,
      summary: result.trip.summary,
      shape: result.trip.legs[0].shape,
    };
  }
  assert.equal(observations.route_1.shape, observations.route_2.shape);
  assert.ok(
    Math.abs(
      observations.route_1.summary.time - observations.route_2.summary.time,
    ) <= 1e-6,
  );
} catch (error) {
  failure = String(error?.stack ?? error);
} finally {
  if (created) {
    const exists = docker(["inspect", name], { allow: true });
    if (exists.status === 0) {
      const c = JSON.parse(exists.stdout)[0];
      assert.equal(c.Config.Labels["io.routelens.p09-probe"], run);
      assert.ok(
        c.Mounts.some((m) => m.Destination === "/work" && m.Source === output),
      );
      exec(
        [
          "/bin/sh",
          "-c",
          'if test -s /work/daemon.pid; then p=$(cat /work/daemon.pid); if kill -0 "$p" 2>/dev/null; then kill -TERM "$p"; fi; fi',
        ],
        { allow: true },
      );
      const deadline = Date.now() + 30000;
      while (Date.now() < deadline) {
        const r = exec(
          [
            "/bin/sh",
            "-c",
            'if test ! -s /work/daemon.pid; then exit 0; fi; p=$(cat /work/daemon.pid); if test ! -e "/proc/$p/stat"; then exit 0; fi; exit 1',
          ],
          { allow: true },
        );
        if (r.status === 0) {
          daemonCleanup = true;
          break;
        }
        await new Promise((r) => setTimeout(r, 200));
      }
      docker(["rm", "-f", name]);
    }
    const gone = docker(["container", "inspect", name], { allow: true });
    cleanup =
      gone.status !== 0 && /No such (?:object|container)/i.test(gone.stderr);
    const listed = docker([
      "ps",
      "-a",
      "--filter",
      "label=io.routelens.p09-probe=" + run,
      "--format",
      "{{.ID}} {{.Names}}",
    ]);
    cleanup = cleanup && !listed.stdout.trim();
  }
  writeFileSync(
    join(output, "observations.json"),
    JSON.stringify(observations, null, 2) + "\n",
  );
  writeFileSync(
    join(output, "result.json"),
    JSON.stringify(
      {
        status: failure
          ? "INCOMPLETE"
          : cleanup
            ? "OBSERVED"
            : "CLEANUP_FAILED",
        failure: failure ?? null,
        daemon_absent_before_container_removal: daemonCleanup,
        owned_container_absence_verified: cleanup,
        scope_en:
          "Capability observation only; no P09 implementation/design completion or drain guarantees.",
        scope_ko:
          "실행 능력 관찰일 뿐 P09 구현·설계 완료나 기존 요청 마무리 보장이 아닙니다.",
      },
      null,
      2,
    ) + "\n",
  );
  if (failure || !cleanup) process.exitCode = 1;
}
