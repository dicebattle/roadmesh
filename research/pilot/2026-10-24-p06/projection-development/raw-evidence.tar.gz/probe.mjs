import {copyFileSync,readFileSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {loadSeoulGraph} from '../../dist/tools/seoul_bundle.js';
import {runSeoulMatching} from '../../dist/tools/seoul_simulation.js';
const source=resolve('data/p06-design-probe-01'),out=resolve('data/p06-design-probe-02');
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const write=(name,value)=>writeFileSync(join(out,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const median=values=>{const sorted=[...values].sort((a,b)=>a-b);return sorted.length%2?sorted[Math.floor(sorted.length/2)]:(sorted[sorted.length/2-1]+sorted[sorted.length/2])/2;};
try {
 const bindings={};
 for(const name of ['expected.json','spec.json','observations.json','truth.json','matching-input.json']) {copyFileSync(join(source,name),join(out,name));bindings[name]={source_sha256:hash(join(source,name)),copied_sha256:hash(join(out,name))};if(bindings[name].source_sha256!==bindings[name].copied_sha256)throw Error('Preserved input hash mismatch / 보존 입력 해시 불일치');}
 write('preserved-input-hashes.json',bindings);
 const expected=JSON.parse(readFileSync(join(out,'expected.json'))),input=JSON.parse(readFileSync(join(out,'matching-input.json'))),graph=loadSeoulGraph('data/p05-main-20261024-r4/seoul/graph');
 write('execution.json',{description_en:'One approved development replay using byte-identical preserved expectations and observed input, without generation or compilation.',description_ko:'생성·컴파일 없이 바이트가 동일한 보존 예상값과 관측 입력을 사용하는 승인된 개발 재생입니다.',policy:'seoul-observed-v3',node:process.version,compiled_module_sha256:Object.fromEntries(['seoul_bundle','seoul_simulation','vehicle_simulator','matching_evidence'].map(name=>[name,hash(`dist/tools/${name}.js`)])),source_sha256:Object.fromEntries(['seoul_simulation','matching_evidence'].map(name=>[name,hash(`tools/${name}.ts`)])),started_at_utc:new Date().toISOString()});
 console.log(JSON.stringify({stage:'matching-started',policy:'seoul-observed-v3',preserved_hashes_match:true,target_count:5}));
 const result=runSeoulMatching(graph,input,join(out,'matching'),'full','seoul-observed-v3');
 const evaluations=expected.expected.map(row=>{const all=result.traversals.filter(tr=>tr.vehicle_id===row.vehicle_id&&tr.edge_id===row.target_edge_id),accepted=all.filter(tr=>tr.status==='ACCEPTED');const duration=accepted.length===1?accepted[0].exited_at_ms-accepted[0].entered_at_ms:null;return {vehicle_id:row.vehicle_id,speed_mps:row.speed_mps,target_edge_id:row.target_edge_id,expected_duration_ms:row.expected_duration_ms,accepted_target_occurrences:accepted.length,actual_duration_ms:duration,duration_error_ms:duration===null?null:Math.abs(duration-row.expected_duration_ms),actual:all};});
 const expectedMedian=median(expected.expected.map(row=>row.expected_duration_ms)),actualDurations=evaluations.flatMap(row=>row.actual_duration_ms===null?[]:[row.actual_duration_ms]),actualMedian=actualDurations.length===5?median(actualDurations):null,length=expected.expected[0].target_distance_m,expectedSpeed=length/(expectedMedian/1000),actualSpeed=actualMedian===null?null:length/(actualMedian/1000),speedError=actualSpeed===null?null:Math.abs(actualSpeed-expectedSpeed)/expectedSpeed;
 const commands=JSON.parse(readFileSync(join(out,'matching/commands.json'))),create=commands.find(c=>c.args[0]==='create'),name=create.args[create.args.indexOf('--name')+1],inspected=spawnSync('docker',['container','inspect',name],{encoding:'utf8'}),absence=inspected.status!==0&&/no such (container|object)/i.test(inspected.stderr);
 write('independent-cleanup.json',{container:name,inspect_exit:inspected.status,stdout:inspected.stdout,stderr:inspected.stderr,absence_verified:absence});
 const summary={status:evaluations.every(row=>row.accepted_target_occurrences===1&&row.duration_error_ms<=150)&&speedError!==null&&speedError<=.02&&absence&&result.policy_id==='seoul-observed-v3'?'PASS':'FAIL',policy_id:result.policy_id,graph_id:graph.graphId,all_preserved_input_hashes_match:true,total_accepted_traversals:result.accepted_traversals,total_excluded_traversals:result.excluded_traversals,target_accepted_traversals:evaluations.reduce((sum,row)=>sum+row.accepted_target_occurrences,0),expected_median_duration_ms:expectedMedian,actual_median_duration_ms:actualMedian,expected_speed_mps:expectedSpeed,actual_speed_mps:actualSpeed,relative_speed_error:speedError,cleanup_verified:absence,evaluations};
 write('summary.json',summary);console.log(JSON.stringify({...summary,evaluations:evaluations.map(({actual,...row})=>row)}));process.exitCode=summary.status==='PASS'?0:1;
}catch(error){write('failure.json',{status:'FAIL',message:String(error),stack:error?.stack});console.error(error);process.exitCode=1;}
