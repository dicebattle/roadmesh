import {readFileSync,writeFileSync} from 'node:fs';
const base='data/p07-claim-fix-main-20261025';const out='data/p08-traffic-format-probe';
const graph=JSON.parse(readFileSync(base+'/seoul/graph/manifest.json'));
const artifact=JSON.parse(readFileSync(base+'/publication/public/committed-sequence-1-artifact.json'));
const targets=artifact.entries.filter(x=>x.status==='LIVE');if(targets.length!==3)throw Error('Expected exactly three LIVE targets');
const config=JSON.parse(readFileSync(base+'/seoul/graph/config.json'));Object.assign(config.mjolnir,{tile_dir:'/graph/tiles',tile_extract:'/work/graph.tar',traffic_extract:'/work/traffic.tar',admin:'/work/no-admin.sqlite',timezone:'/work/no-timezone.sqlite'});
writeFileSync(out+'/build-config.json',JSON.stringify(config,null,2));
const request=JSON.parse(readFileSync(base+'/seoul/graph/route-teheran.request.json'));request.date_time={type:0};writeFileSync(out+'/route.request.json',JSON.stringify(request,null,2));
writeFileSync(out+'/expected.json',JSON.stringify({written_before_execution:true,graph_id:graph.graph_id,image_id:graph.image.id,targets,historical_artifact:true,not_p07_acceptance:true,variants:['baseline','slow10','slow2','restore'],requirements:{valid_route_count:4,restore_same_shape:true,restore_time_absolute_tolerance_seconds:1e-6},direction_hypothesis_en:'Lower selected edge speeds should increase length-based travel time if those directed edges are used; route or time changes are observations, not independent expected paths. No effect is not a pass.',direction_hypothesis_ko:'선택한 방향 구간을 이용한다면 낮은 속도는 길이 기반 통과시간을 늘릴 것으로 예상합니다. 경로·시간 변화는 관찰이며 독립 정답이 아닙니다. 효과 없음을 통과로 보지 않습니다.'},null,2));
