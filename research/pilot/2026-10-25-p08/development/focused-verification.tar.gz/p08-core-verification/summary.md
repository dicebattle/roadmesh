# P08 core handoff / P08 코어 전달

## English

Implementation owner: assigned Sol core agent. Main fixed docs27 and reviewed scope before implementation; integration agent owns scenario/checks/report/whole-run changes. Core tracked writes are frozen after the final focused verification. No commit, push, real traffic_checks execution or whole-pipeline execution was performed by this core agent.

Files: traffic_types (agreed boundaries), traffic_bundle (unchanged upstream preparation, strict bounded TAR/index/layout/catalog validation, graph/image/hash binding), traffic_compiler (positive-speed quantization, exact-record patching, exact artifact/snapshot validation, durable staged atomic immutable generations and collision/corruption refusal), traffic_controller (actual P07 accepted-state authorization before compilation, before engine use and after engine result), traffic_runtime (owned actual Valhalla/current-time route and edge_walk trace with bounded failures and exact cleanup), traffic_worker (private0600 config/IPC/phase CLI), narrow publication consumer/types inspection and package scripts. Two new focused test files cover the codec/cache/request and atomic inspection boundaries.

`PublicationConsumer.inspectAccepted()` obtains high_water, active bytes and checked_at_event_time in the existing same clock SHARE/state UPDATE transaction. Existing status() still returns exactly its original two fields. Controller does not perform a redundant verifyInitialized call: DB connectivity failures remain STORE_UNAVAILABLE through the atomic inspection path. Before/after accepted identity/high-water changes are ACCEPTED_STATE_CHANGED and never relabeled baseline. Genuine no usable state uses blank speeds; a valid non-LIVE snapshot retains its ID with NO_LIVE_COVERAGE.

Engine responses are returned as {request,route,trace}, separately retained as raw command logs/request/response files in owned generation_root/runtime paths. Public provenance excludes paths and private inputs. Only private AFTER_ENGINE_READY IPC includes exact engine container/run directory for parent ownership-checked fault injection. Normal cleanup is verified; killed engines are recognizable to the existing parent runtime by exact owner label and owned /work mount. Bundle cleanup false is BUNDLE_CLEANUP and cannot return success.

Verification using Node22.23.2:

```
PATH=/Users/dice/.local/share/mise/installs/node/22.23.2/bin:$PATH npm run build
PATH=/Users/dice/.local/share/mise/installs/node/22.23.2/bin:$PATH node --test dist/tests/traffic_core.test.js dist/tests/traffic_consumer.test.js dist/tests/publication_core.test.js
git diff --check
```

The first coordinated build failed on two integration-owned type errors (literal narrowing in pilot_integration and consent_version widening in traffic_checks); build.log preserves the failure. The integration agent corrected them and build-retry.log passed. Main then requested the final bundle-cleanup and redundant-query corrections; build-final.log passed after those source changes. No successful build was repeated merely for different output. Offline cached prettier3.6.2 formatted only core-owned new files, without dependency/package-lock changes; format.log preserves the command output.

Focused suite ran once:21/21 passed,0 failed,0 skipped (7 new core tests plus14 affected publication core tests). Existing production API has no SQL injection hook. Atomic-consumer unit test replaces a private lazy pool only within that test; it proves query transaction shape, not real database concurrency. Codec TAR fixtures are explicitly authored format tests, not compiled C++ ABI evidence. Temporary test directories are removed in finally; these tests start no engines, database or servers. source-hashes.json binds each core-owned artifact at handoff.

Remaining proof: main must run the fresh actual15-trip P05→P06→P07→P08 development and then full clean pipeline, examine DB/hash/route/cost/trace/expiry/crash/concurrency originals and browser/media. This handoff does not claim those end-to-end outcomes or P08 completion. No compiler installation, dependency installation, engine fork or Python reimplementation was added.

## 한국어

메인이 고정한 docs27과 공유 인터페이스에 따라 Sol 코어 구현을 완료했습니다. 실제 교통파일 생성·엄격한 형식 검사·양자화·불변 세대 원자 게시·실제 수용 상태의 반복 확인·소유 Valhalla 경로/trace·비공개 처리자를 연결했습니다. 기존 P07 status 출력은 그대로 두고 같은 트랜잭션의 수용 상태와 관측시각을 반환하는 inspectAccepted만 추가했습니다.

속도는 유한한 양수만1~126으로 변환하고 선택한8바이트 기록만 바꿉니다. 원문 파일 해시·길이와 파싱한 snapshot을 대조합니다. 준비/엔진실행/응답 사이 수용 상태가 바뀌면 명시적으로 실패하며 기존 경로에 다른 버전 정보를 붙이지 않습니다. 사용 가능한 자료가 없으면 빈 파일을 사용하고, 유효하지만 LIVE가 없는 자료는 원래 snapshot ID와 NO_LIVE_COVERAGE를 유지합니다. 손상 캐시·묶음·DB·엔진 오류는 성공 경로로 숨기지 않습니다.

마지막 공유 Node22 엄격 빌드와 코어 신규7개·영향 P07검사14개 합계21개가 통과했습니다. 첫 빌드의 통합 소유 타입오류 두 개, 해당 수정 재빌드, 이후 메인 검토 보완 뒤 최종 빌드의 원문을 모두 보존했습니다. 집중 검사는 한 번만 실행했고 생략은 없습니다. git diff --check도 통과했습니다. 실제 DB/엔진/전체 흐름을 시작하거나 커밋·푸시하지 않았으며 모든 tracked write를 동결했습니다.

검사는 실제 형식의 코드 계약·파일 상태·조회 트랜잭션 구조를 확인한 것이며 실제 C++ ABI나 DB 경쟁·15명 전체 처리 흐름 증거로 표현하지 않습니다. 다음 실제 개발 실행·전체 실행·독립 원문 검증·화면/녹화는 메인이 맡습니다. 이 전달을 P08 완료로 표현하지 않습니다.
